import React, { useState } from "react";
import { QuizQuestion } from "../lib/gemini";
import { AITutor } from "./AITutor";
import { CheckCircle, XCircle, ArrowRight, RotateCcw, Bot } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkMath from "remark-math";
import rehypeKatex from "rehype-katex";
import { cn } from "../lib/utils";

interface QuizRunnerProps {
  questions: QuizQuestion[];
  onRestart: () => void;
}

export function QuizRunner({ questions, onRestart }: QuizRunnerProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [showTutor, setShowTutor] = useState(false);
  const [score, setScore] = useState(0);

  const question = questions[currentIndex];
  const isCorrect = selectedOption === question.correctOptionIndex;

  const handleSelect = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
    setIsAnswered(true);

    if (index === question.correctOptionIndex) {
      setScore((s) => s + 1);
    } else {
      setShowTutor(true);
    }
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex((c) => c + 1);
      setSelectedOption(null);
      setIsAnswered(false);
      setShowTutor(false);
    } else {
      // Finished
      setCurrentIndex(questions.length);
    }
  };

  if (currentIndex >= questions.length) {
    return (
      <div className="w-full h-full flex items-center justify-center p-8 bg-slate-50">
        <div className="w-full max-w-2xl p-8 bg-white rounded-2xl shadow-sm border border-slate-100 text-center">
          <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10" />
          </div>
          <h2 className="text-3xl font-bold text-slate-800 mb-4">¡Cuestionario Completado!</h2>
          <p className="text-xl text-slate-600 mb-8">
            Tu puntaje: <span className="font-bold text-indigo-600">{score}</span> de {questions.length}
          </p>
          <button
            onClick={onRestart}
            className="px-8 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-xl transition-colors inline-flex items-center space-x-2"
          >
            <RotateCcw className="w-5 h-5" />
            <span>Volver al Repositorio</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full flex flex-col lg:flex-row bg-slate-50">
      {/* Question Column (3/4) */}
      <div className="w-full lg:w-3/4 h-full overflow-y-auto p-6 lg:p-8">
        <div className="max-w-4xl mx-auto bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-6">
            <span className="text-sm font-medium text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full">
              Pregunta {currentIndex + 1} de {questions.length}
            </span>
            <span className="text-sm text-slate-500">Puntaje: {score}</span>
          </div>

          {/* Question Content (Image or Text fallback) */}
          <div className="mb-8">
            {question.imageBase64 ? (
              <img 
                src={question.imageBase64} 
                alt="Pregunta" 
                className="w-full object-contain rounded-lg border border-slate-200"
              />
            ) : (
              <div className="prose prose-slate max-w-none">
                <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>
                  {question.text}
                </ReactMarkdown>
              </div>
            )}
          </div>

          {/* Options */}
          <div className="space-y-3">
            {question.options.map((option, idx) => {
              const isSelected = selectedOption === idx;
              const isCorrectOption = idx === question.correctOptionIndex;
              
              let buttonClass = "border-slate-200 hover:border-indigo-400 hover:bg-slate-50";
              if (isAnswered) {
                if (isCorrectOption) {
                  buttonClass = "border-emerald-500 bg-emerald-50 text-emerald-900";
                } else if (isSelected && !isCorrectOption) {
                  buttonClass = "border-red-500 bg-red-50 text-red-900";
                } else {
                  buttonClass = "border-slate-200 opacity-50";
                }
              } else if (isSelected) {
                buttonClass = "border-indigo-500 bg-indigo-50 text-indigo-900";
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelect(idx)}
                  disabled={isAnswered}
                  className={cn(
                    "w-full text-left p-4 rounded-xl border-2 transition-all flex items-start space-x-3",
                    buttonClass
                  )}
                >
                  <div className="flex-shrink-0 mt-0.5">
                    {isAnswered && isCorrectOption ? (
                      <CheckCircle className="w-5 h-5 text-emerald-500" />
                    ) : isAnswered && isSelected && !isCorrectOption ? (
                      <XCircle className="w-5 h-5 text-red-500" />
                    ) : (
                      <div className="w-5 h-5 rounded-full border-2 border-slate-300 flex items-center justify-center">
                        <span className="text-xs font-medium text-slate-500">
                          {String.fromCharCode(65 + idx)}
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="flex-1 prose prose-sm max-w-none">
                    <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>
                      {option}
                    </ReactMarkdown>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Next Button */}
          {isAnswered && (
            <div className="mt-8 pt-6 border-t border-slate-100 flex justify-end">
              <button
                onClick={handleNext}
                className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-xl transition-colors inline-flex items-center space-x-2"
              >
                <span>{currentIndex < questions.length - 1 ? "Siguiente Pregunta" : "Ver Resultados"}</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Tutor Column (1/4) */}
      <div className="w-full lg:w-1/4 h-full border-t lg:border-t-0 lg:border-l border-slate-200 bg-white flex flex-col">
        {showTutor && selectedOption !== null ? (
          <AITutor question={question} userWrongAnswerIndex={selectedOption} />
        ) : isAnswered && isCorrect ? (
          <div className="h-full bg-emerald-50 p-8 flex flex-col items-center justify-center text-center animate-in fade-in duration-500">
            <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mb-6">
              <CheckCircle className="w-10 h-10" />
            </div>
            <h3 className="text-2xl font-bold text-emerald-800 mb-2">¡Excelente trabajo!</h3>
            <p className="text-emerald-600">Respondiste correctamente. Puedes continuar con la siguiente pregunta.</p>
          </div>
        ) : (
          <div className="h-full bg-slate-50 p-8 flex flex-col items-center justify-center text-center">
            <div className="w-20 h-20 bg-white shadow-sm text-slate-400 rounded-full flex items-center justify-center mb-6">
              <Bot className="w-10 h-10" />
            </div>
            <h3 className="text-xl font-medium text-slate-700 mb-2">Tutor IA PAES</h3>
            <p className="text-slate-500 text-sm">
              El tutor se activará automáticamente si te equivocas en alguna respuesta para ayudarte a entender el problema.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

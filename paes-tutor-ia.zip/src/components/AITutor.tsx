import React, { useState, useRef, useEffect } from "react";
import { QuizQuestion, chatWithTutor } from "../lib/gemini";
import { Send, Bot, User, Loader2 } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkMath from "remark-math";
import rehypeKatex from "rehype-katex";
import { cn } from "../lib/utils";

interface AITutorProps {
  question: QuizQuestion;
  userWrongAnswerIndex: number;
}

interface Message {
  role: "user" | "model";
  text: string;
}

export function AITutor({ question, userWrongAnswerIndex }: AITutorProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesContainerRef = useRef<HTMLDivElement>(null);

  // Initial message from the tutor
  useEffect(() => {
    const initTutor = async () => {
      setIsLoading(true);
      try {
        const stream = await chatWithTutor(question, userWrongAnswerIndex, [], "¡Hola! Me equivoqué en esta pregunta. ¿Me ayudas?");
        
        let fullText = "";
        setMessages([{ role: "user", text: "¡Hola! Me equivoqué en esta pregunta. ¿Me ayudas?" }, { role: "model", text: "" }]);
        
        for await (const chunk of stream) {
          const chunkText = (chunk as any).text || "";
          fullText += chunkText;
          setMessages((prev) => {
            const newMessages = [...prev];
            newMessages[newMessages.length - 1].text = fullText;
            return newMessages;
          });
        }
      } catch (error) {
        console.error(error);
        setMessages((prev) => [...prev, { role: "model", text: "Hubo un error al conectar con el tutor. Por favor, intenta de nuevo." }]);
      } finally {
        setIsLoading(false);
      }
    };

    initTutor();
  }, [question, userWrongAnswerIndex]);

  useEffect(() => {
    if (messagesContainerRef.current) {
      messagesContainerRef.current.scrollTop = messagesContainerRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input.trim();
    setInput("");
    
    // We don't include the very first auto-generated user message in the history we send, 
    // or we can just send everything. Let's send everything.
    const historyToSend = [...messages];
    
    setMessages((prev) => [...prev, { role: "user", text: userMsg }, { role: "model", text: "" }]);
    setIsLoading(true);

    try {
      const stream = await chatWithTutor(question, userWrongAnswerIndex, historyToSend, userMsg);
      
      let fullText = "";
      for await (const chunk of stream) {
        const chunkText = (chunk as any).text || "";
        fullText += chunkText;
        setMessages((prev) => {
          const newMessages = [...prev];
          newMessages[newMessages.length - 1].text = fullText;
          return newMessages;
        });
      }
    } catch (error) {
      console.error(error);
      setMessages((prev) => {
        const newMessages = [...prev];
        newMessages[newMessages.length - 1].text = "Hubo un error al conectar con el tutor.";
        return newMessages;
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 overflow-hidden">
      <div className="bg-indigo-600 p-4 flex items-center space-x-3 text-white">
        <Bot className="w-6 h-6" />
        <div>
          <h3 className="font-medium">Tutor IA PAES</h3>
          <p className="text-xs text-indigo-200">Respuestas rápidas con Gemini Flash Lite</p>
        </div>
      </div>

      <div 
        ref={messagesContainerRef}
        className="flex-1 overflow-y-auto p-4 space-y-4"
      >
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={cn(
              "flex max-w-[85%]",
              msg.role === "user" ? "ml-auto justify-end" : "mr-auto justify-start"
            )}
          >
            <div
              className={cn(
                "p-3 rounded-2xl",
                msg.role === "user"
                  ? "bg-indigo-600 text-white rounded-br-sm"
                  : "bg-white border border-slate-200 text-slate-800 rounded-bl-sm"
              )}
            >
              <div
                className={cn(
                  "prose prose-sm max-w-none",
                  msg.role === "user" ? "prose-invert" : ""
                )}
              >
                <ReactMarkdown
                  remarkPlugins={[remarkMath]}
                  rehypePlugins={[rehypeKatex]}
                >
                  {msg.text}
                </ReactMarkdown>
              </div>
            </div>
          </div>
        ))}
        {isLoading && messages[messages.length - 1]?.role === "user" && (
          <div className="flex max-w-[85%] mr-auto justify-start">
            <div className="p-3 rounded-2xl bg-white border border-slate-200 text-slate-800 rounded-bl-sm flex items-center space-x-2">
              <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
              <span className="text-sm text-slate-500">Escribiendo...</span>
            </div>
          </div>
        )}
      </div>

      <div className="p-3 bg-white border-t border-slate-200">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center space-x-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Escribe tu respuesta o duda..."
            className="flex-1 px-4 py-2 bg-slate-100 border-transparent rounded-full focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="p-2 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
}

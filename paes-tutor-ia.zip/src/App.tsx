import React, { useState, useEffect } from 'react';
import { QuizSetup } from './components/QuizSetup';
import { QuizRunner } from './components/QuizRunner';
import { BookOpen, Plus, Trash2, Clock, GraduationCap, UserCog, LogIn } from 'lucide-react';
import { getQuizzes, deleteQuiz, Quiz } from './lib/db';
import { cn } from './lib/utils';

export default function App() {
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [currentQuiz, setCurrentQuiz] = useState<Quiz | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [role, setRole] = useState<'student' | 'teacher'>('teacher');

  useEffect(() => {
    loadQuizzes();
  }, []);

  const loadQuizzes = async () => {
    const loaded = await getQuizzes();
    setQuizzes(loaded.sort((a, b) => b.createdAt - a.createdAt));
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('¿Estás seguro de que deseas eliminar este ensayo?')) {
      await deleteQuiz(id);
      await loadQuizzes();
    }
  };

  const handleQuizGenerated = async (quiz: Quiz) => {
    await loadQuizzes();
    setCurrentQuiz(quiz);
    setIsCreating(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div 
            className="flex items-center space-x-3 cursor-pointer"
            onClick={() => {
              setCurrentQuiz(null);
              setIsCreating(false);
            }}
          >
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-sm">
              <BookOpen className="w-6 h-6" />
            </div>
            <h1 className="text-xl font-bold text-slate-800 tracking-tight hover:text-indigo-600 transition-colors hidden sm:block">
              PAES Tutor IA
            </h1>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Role Toggle */}
            <div className="flex bg-slate-100 p-1 rounded-lg">
              <button
                onClick={() => { 
                  setRole('student'); 
                  setCurrentQuiz(null); 
                  setIsCreating(false); 
                }}
                className={cn(
                  "px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center space-x-2",
                  role === 'student' ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                )}
              >
                <GraduationCap className="w-4 h-4" />
                <span className="hidden sm:inline">Alumno</span>
              </button>
              <button
                onClick={() => { 
                  setRole('teacher'); 
                  setCurrentQuiz(null); 
                }}
                className={cn(
                  "px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center space-x-2",
                  role === 'teacher' ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                )}
              >
                <UserCog className="w-4 h-4" />
                <span className="hidden sm:inline">Profesora</span>
              </button>
            </div>

            {role === 'student' && (
              <button
                onClick={() => {
                  setCurrentQuiz(null);
                  alert("En el futuro, este botón te permitirá iniciar sesión con tu contraseña.");
                }}
                className="text-sm font-medium text-slate-500 hover:text-indigo-600 transition-colors flex items-center space-x-1"
              >
                <LogIn className="w-4 h-4" />
                <span className="hidden sm:inline">Volver a ingresar</span>
              </button>
            )}

            {(currentQuiz || isCreating) && (
              <button
                onClick={() => {
                  setCurrentQuiz(null);
                  setIsCreating(false);
                }}
                className="text-sm font-medium text-slate-500 hover:text-slate-800 transition-colors"
              >
                Volver al Repositorio
              </button>
            )}
          </div>
        </div>
      </header>

      <main className={cn(
        "mx-auto transition-all",
        currentQuiz ? "w-full h-[calc(100vh-4rem)]" : "max-w-7xl px-4 sm:px-6 lg:px-8 py-12"
      )}>
        {currentQuiz ? (
          <QuizRunner 
            questions={currentQuiz.questions} 
            onRestart={() => setCurrentQuiz(null)} 
          />
        ) : isCreating && role === 'teacher' ? (
          <QuizSetup onQuizGenerated={handleQuizGenerated} />
        ) : (
          <div className="space-y-8">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-slate-800">Repositorio de Ensayos</h2>
                <p className="text-slate-500">
                  {role === 'teacher' ? 'Administra tus ensayos y cuestionarios.' : 'Selecciona un ensayo para comenzar a practicar.'}
                </p>
              </div>
              {role === 'teacher' && (
                <button
                  onClick={() => setIsCreating(true)}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-xl transition-colors inline-flex items-center space-x-2 shadow-sm"
                >
                  <Plus className="w-5 h-5" />
                  <span className="hidden sm:inline">Subir Nuevo Ensayo</span>
                </button>
              )}
            </div>

            {quizzes.length === 0 ? (
              <div className="bg-white border border-slate-200 border-dashed rounded-2xl p-12 text-center">
                <div className="w-16 h-16 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-medium text-slate-800 mb-2">Aún no hay ensayos</h3>
                {role === 'teacher' ? (
                  <>
                    <p className="text-slate-500 mb-6 max-w-sm mx-auto">
                      Sube tu primer documento PDF con preguntas tipo PAES para comenzar a practicar con la ayuda del Tutor IA.
                    </p>
                    <button
                      onClick={() => setIsCreating(true)}
                      className="px-6 py-3 bg-white border border-slate-300 hover:border-indigo-400 hover:bg-slate-50 text-slate-700 font-medium rounded-xl transition-colors inline-flex items-center space-x-2"
                    >
                      <Plus className="w-5 h-5 text-indigo-500" />
                      <span>Subir Documento</span>
                    </button>
                  </>
                ) : (
                  <p className="text-slate-500 max-w-sm mx-auto">
                    Tu profesora aún no ha subido ningún ensayo. ¡Vuelve más tarde!
                  </p>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {quizzes.map((quiz) => (
                  <div 
                    key={quiz.id}
                    onClick={() => setCurrentQuiz(quiz)}
                    className="bg-white border border-slate-200 rounded-2xl p-6 hover:border-indigo-400 hover:shadow-md transition-all cursor-pointer group flex flex-col"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                        <BookOpen className="w-6 h-6" />
                      </div>
                      {role === 'teacher' && (
                        <button
                          onClick={(e) => handleDelete(quiz.id, e)}
                          className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100"
                          title="Eliminar ensayo"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                    
                    <h3 className="text-lg font-bold text-slate-800 mb-2 line-clamp-2">
                      {quiz.title}
                    </h3>
                    
                    <div className="mt-auto pt-4 flex items-center justify-between text-sm text-slate-500">
                      <div className="flex items-center space-x-1">
                        <span className="font-medium text-slate-700">{quiz.questions.length}</span>
                        <span>preguntas</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>{new Date(quiz.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

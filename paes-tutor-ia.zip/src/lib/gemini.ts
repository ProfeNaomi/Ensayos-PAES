import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface QuizQuestion {
  id: number;
  pageIndex: number;
  box: [number, number, number, number];
  text: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
  imageBase64?: string;
}

/**
 * Attempts to repair a truncated JSON string by closing open braces and brackets.
 * Useful when the model hits the token limit.
 */
function repairTruncatedJson(jsonStr: string): string {
  jsonStr = jsonStr.trim();
  
  // If it's already valid, return it
  try {
    JSON.parse(jsonStr);
    return jsonStr;
  } catch (e) {
    // Continue to repair
  }

  // Find the last complete object in the array
  // We look for the last "}," and try to close the array there
  const lastCompleteObjectEnd = jsonStr.lastIndexOf("},");
  if (lastCompleteObjectEnd !== -1) {
    return jsonStr.substring(0, lastCompleteObjectEnd + 1) + "]";
  }

  // If we can't find a "},", maybe it's the very last object that is incomplete
  const lastObjectStart = jsonStr.lastIndexOf("{");
  if (lastObjectStart > 0) {
    return jsonStr.substring(0, lastObjectStart).trim().replace(/,$/, "") + "]";
  }

  return "[]";
}

export async function generateQuizFromPDFs(
  questionsPdfBase64: string,
  solutionsPdfBase64: string | null
): Promise<QuizQuestion[]> {
  const parts: any[] = [
    {
      inlineData: {
        data: questionsPdfBase64,
        mimeType: "application/pdf",
      },
    },
    {
      text: "Extract all the multiple-choice math questions from this document. It is a Chilean PAES Math test.",
    },
  ];

  if (solutionsPdfBase64) {
    parts.push({
      inlineData: {
        data: solutionsPdfBase64,
        mimeType: "application/pdf",
      },
    });
    parts.push({
      text: "Use this solutions document to determine the correct answers and explanations for each question.",
    });
  } else {
    parts.push({
      text: "Since no solutions document was provided, please solve the questions yourself to determine the correct answers and provide a brief explanation.",
    });
  }

  parts.push({
    text: "Return a JSON array of objects. Each object must have:\n- 'id' (number)\n- 'pageIndex' (number, 0-based index of the page where the question is located)\n- 'box' (array of 4 numbers: [ymin, xmin, ymax, xmax] normalized from 0 to 1000, representing the bounding box that tightly encloses the question text and its figures/tables. Do NOT include the options A,B,C,D in the box if possible, just the question prompt and figures)\n- 'text' (string, the transcribed text of the question)\n- 'options' (array of strings, the choices)\n- 'correctOptionIndex' (number, 0-based index of the correct option)\n- 'explanation' (string, concise step-by-step solution).\nKeep the 'explanation' brief but clear to ensure the response fits within limits.\nEnsure math formulas are written in LaTeX format. Do not include any text outside the JSON array.",
  });

  const response = await ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: { parts },
    config: {
      maxOutputTokens: 16384, // Increased from 8192
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.INTEGER },
            pageIndex: { type: Type.INTEGER },
            box: {
              type: Type.ARRAY,
              items: { type: Type.NUMBER },
              description: "[ymin, xmin, ymax, xmax] normalized 0-1000"
            },
            text: { type: Type.STRING },
            options: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            correctOptionIndex: { type: Type.INTEGER },
            explanation: { type: Type.STRING },
          },
          required: ["id", "pageIndex", "box", "text", "options", "correctOptionIndex", "explanation"],
        },
      },
    },
  });

  const rawText = response.text || "";
  if (!rawText) {
    throw new Error("La IA no devolvió ninguna respuesta. Esto puede deberse a filtros de seguridad o a un archivo demasiado complejo.");
  }
  
  let jsonStr = rawText.trim();
  
  // Remove markdown code blocks if present
  if (jsonStr.startsWith("```")) {
    jsonStr = jsonStr.replace(/^```(?:json)?\n?/, "").replace(/\n?```$/, "");
  }

  try {
    const parsed = JSON.parse(jsonStr);
    return (Array.isArray(parsed) ? parsed : []) as QuizQuestion[];
  } catch (e) {
    console.warn("Initial JSON parse failed, attempting repair...", e);
    
    try {
      const repairedJson = repairTruncatedJson(jsonStr);
      const parsed = JSON.parse(repairedJson);
      if (Array.isArray(parsed) && parsed.length > 0) {
        console.log(`Successfully recovered ${parsed.length} questions from truncated response.`);
        return parsed as QuizQuestion[];
      }
    } catch (repairError) {
      console.error("Repair failed:", repairError);
    }

    console.error("Failed to parse JSON. Raw response:", rawText);
    throw new Error("No se pudo procesar la respuesta de la IA. El archivo es muy grande o la respuesta se cortó. Intenta subir menos páginas.");
  }
}

export async function chatWithTutor(
  question: QuizQuestion,
  userWrongAnswerIndex: number,
  chatHistory: { role: "user" | "model"; text: string }[],
  newMessage: string
) {
  const systemInstruction = `Eres un tutor experto en matemáticas para la prueba PAES de Chile.
El estudiante está intentando resolver la siguiente pregunta:
"${question.text}"

Opciones:
${question.options.map((opt, i) => `${i}: ${opt}`).join("\n")}

La respuesta correcta es la opción ${question.correctOptionIndex} (${question.options[question.correctOptionIndex]}).
El estudiante eligió incorrectamente la opción ${userWrongAnswerIndex} (${question.options[userWrongAnswerIndex]}).

Explicación oficial:
${question.explanation}

Tu objetivo es ayudar al estudiante a entender su error y guiarlo hacia la respuesta correcta.
NO le des la respuesta correcta inmediatamente. Hazle preguntas socráticas, dale pistas y explícale los conceptos matemáticos que necesita.
Usa un tono amigable, alentador y utiliza español chileno de manera natural (ej. "¡Hola! Vamos a ver en qué te equivocaste", "Fíjate bien en...", "¡Súper bien!").
Usa formato Markdown y LaTeX para las fórmulas matemáticas.`;

  const contents = chatHistory.map((msg) => ({
    role: msg.role,
    parts: [{ text: msg.text }],
  }));

  contents.push({
    role: "user",
    parts: [{ text: newMessage }],
  });

  const response = await ai.models.generateContentStream({
    model: "gemini-3.1-flash-lite-preview",
    contents,
    config: {
      systemInstruction,
    },
  });

  return response;
}

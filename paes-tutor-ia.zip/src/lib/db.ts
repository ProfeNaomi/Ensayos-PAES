import { get, set } from 'idb-keyval';
import { QuizQuestion } from './gemini';

export interface Quiz {
  id: string;
  title: string;
  createdAt: number;
  questions: QuizQuestion[];
}

export async function getQuizzes(): Promise<Quiz[]> {
  return (await get('paes_quizzes')) || [];
}

export async function saveQuiz(quiz: Quiz): Promise<void> {
  const quizzes = await getQuizzes();
  quizzes.push(quiz);
  await set('paes_quizzes', quizzes);
}

export async function deleteQuiz(id: string): Promise<void> {
  const quizzes = await getQuizzes();
  await set('paes_quizzes', quizzes.filter(q => q.id !== id));
}
